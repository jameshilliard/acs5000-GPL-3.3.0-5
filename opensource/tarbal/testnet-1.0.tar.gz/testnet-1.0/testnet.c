#include <error.h>
#include <errno.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/poll.h>

#define BYTES_PER_LINE 8

void printbuf(char *buf, int tam)
{
        int i, j, lines;

	// print number of bytes received	
        printf("Buffer received - %d bytes\n", tam);

        // define number of lines to print
	lines = tam / BYTES_PER_LINE;
	if ((tam % BYTES_PER_LINE) > 0)
		lines++;

	// print the lines
	for (i = 0; i < lines; i++) {

		// print bytes in hexa
		for (j = 0; j < BYTES_PER_LINE && (i * BYTES_PER_LINE + j) < tam; j++)
			printf("%02X ", (unsigned char)buf[i * BYTES_PER_LINE + j]);

		// adjust spaces
		while (j < BYTES_PER_LINE) {
			printf("   ");
			j++;
		}
		printf("\t");

		// print bytes in ASCII
		for (j = 0; j < BYTES_PER_LINE && (i * BYTES_PER_LINE + j) < tam; j++)
			printf("%c ", isprint((unsigned char)buf[i * BYTES_PER_LINE + j]) ?
				(unsigned char)buf[i * BYTES_PER_LINE + j] : '.');

		// next line
		printf("\n");
	}
}

void show_options()
{
	printf("Use: testnet <port_number>\n");
	exit(1);
}

int main (int argc, char *argv[])
{
        struct addrinfo *ai;
	struct addrinfo hints;

	if (argc != 2) {
		printf("Invalid number of arguments!\n");
		show_options();
	}
        	
	memset (&hints, '\0', sizeof (hints));
	hints.ai_flags = AI_PASSIVE;
	hints.ai_socktype = SOCK_STREAM;
	if (getaddrinfo(NULL, argv[1], &hints, &ai) != 0)
		error (EXIT_FAILURE, 0, "getaddrinfo: %s", gai_strerror(errno));
	    
	struct pollfd fds[2];
	int nfds = 0;
	struct addrinfo *runp = ai;
	
	while (runp != NULL && nfds < 2) {

		int opt = 1;

		fds[nfds].fd = socket (runp->ai_family, runp->ai_socktype,
			runp->ai_protocol);

		if (fds[nfds].fd == -1)
			error (EXIT_FAILURE, errno, "socket");
			
		fds[nfds].events = POLLIN;
		
		setsockopt (fds[nfds].fd, SOL_SOCKET, SO_REUSEADDR,
			opt, sizeof (opt));

		if (bind (fds[nfds].fd, runp->ai_addr, runp->ai_addrlen) != 0) {
			if (errno != EADDRINUSE)
				error (EXIT_FAILURE, errno, "bind");
			close (fds[nfds].fd);
		}
		else {
			if (listen (fds[nfds].fd, SOMAXCONN) != 0)
				error (EXIT_FAILURE, errno, "listen");
			++nfds;

			char buf1[200];
			if (getnameinfo ((struct sockaddr *) runp->ai_addr, runp->ai_addrlen,
				buf1, sizeof (buf1), NULL, 0, NI_NUMERICHOST) != 0) {
				strcpy (buf1, "???");
			}
			printf ("listen to %s:%s\n", buf1, argv[1]);
		}
		runp = runp->ai_next;
	}

	freeaddrinfo (ai);

	while (1) {

                int n = poll (fds, nfds, -1);

		if (n > 0) {

			int i;
			
			for (i = 0; i < nfds; ++i) {

				if (fds[i].revents & POLLIN) {

					struct sockaddr_storage rem;
					socklen_t remlen = sizeof (rem);

					int fd = accept (fds[i].fd, (struct sockaddr *) &rem, &remlen);
					if (fd != -1) {

						char buf1[200];
						if (getnameinfo ((struct sockaddr *) &rem, remlen,
							buf1, sizeof (buf1), NULL, 0, 0) != 0) {
							strcpy (buf1, "???");
						}

						char buf2[100];
						(void) getnameinfo ((struct sockaddr *) &rem, remlen,
							buf2, sizeof (buf2), NULL, 0,
							NI_NUMERICHOST);
						printf ("connection from %s (%s)\n", buf1, buf2);

						char buf[1000];
						ssize_t l = read (fd, buf, sizeof (buf));
						printbuf(buf, l);
						close (fd);
					}
				}
			}
		}
	}

	return(0);
}
