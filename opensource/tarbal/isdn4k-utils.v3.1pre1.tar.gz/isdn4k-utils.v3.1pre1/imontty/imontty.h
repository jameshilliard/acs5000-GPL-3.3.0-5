/* tty line ISDN status monitor
 *
 * (c) 1995-97 Volker G�tz
 *
 * $Id: imontty.h,v 1.1 1997/03/03 04:10:12 fritz Exp $
 */

#define		PATH_ISDNINFO	"/dev/isdninfo"
#define		IM_BUFSIZE	10 + (22 * ISDN_MAX_CHANNELS)
#define		IM_VERSION	"0.5"
