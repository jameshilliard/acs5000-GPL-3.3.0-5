/*
 *  Module:  test_getifaddrs.c
 *
 *  Description: Program to test getifaddrs() function
 *
 *  Author:  Sergio Prado <sergio.prado@avocent.com>
 *
 *  Copyright:  (c) 2007 Avocent Corporation
 *
 *  Date:  October 4, 2007
 *
 *  Comments:
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <limits.h>

#include "getifaddrs6.h"

int main()
{
	struct ifaddrs *ifa, *ptr;
	char addr[200];
	int len = 0;

        getifaddrs6(&ifa);

        /* save list ptr */
        ptr = ifa;

	while (ifa != NULL) {
		printf("\nName=%s\n", ifa->ifa_name);
		
                printf("Flags=%X UP=%d\n", ifa->ifa_flags,
			(ifa->ifa_flags & IFF_UP) ? 1 : 0);
			
                printf("Family=%d\n", ifa->ifa_addr->sa_family);

		switch (ifa->ifa_addr->sa_family) {
			case AF_INET:
				len = sizeof(struct sockaddr_in);
				break;

			case AF_INET6:
				len = sizeof(struct sockaddr_in6);
				break;
		}

		if ((getnameinfo(ifa->ifa_addr, len, addr, sizeof(addr),
				NULL, 0, NI_NUMERICHOST)) == 0) {
			printf("Address: %s\n", addr);
		}
		else {
			perror("Error getting IP address");
		}

		if ((getnameinfo(ifa->ifa_netmask, len, addr, sizeof(addr),
				NULL, 0, NI_NUMERICHOST)) == 0) {
			printf("Netmask: %s\n", addr);
		}
		else {
			perror("Error getting Netmask");
		}

		ifa = ifa->ifa_next;		
	}
	printf("\n");

	freeifaddrs6(ptr);

	return(0);
}
