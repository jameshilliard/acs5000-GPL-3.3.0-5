/* $Id: patchlevel.h,v 1.2 2001/05/03 09:00:51 calle Exp $ */

#define VERSION		"2.4.1"
#define DATE		"25 March 2001"
