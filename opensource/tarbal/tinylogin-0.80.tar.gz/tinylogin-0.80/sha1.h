/* SHA1.H - header file for SHA1.C */

char *sha1_crypt(const char *pw);
