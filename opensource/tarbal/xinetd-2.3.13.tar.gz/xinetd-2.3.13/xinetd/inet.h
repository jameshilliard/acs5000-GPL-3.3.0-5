#ifndef X_INET_H
#define X_INET_H

#include "pset.h"
#include "sconf.h"
#include "conf.h"

void parse_inet_conf_file(int fd,struct configuration *confp);

#endif
