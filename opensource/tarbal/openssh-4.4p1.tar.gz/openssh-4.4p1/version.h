/* $OpenBSD: version.h,v 1.47 2006/08/30 00:14:37 djm Exp $ */

#define SSH_VERSION	"OpenSSH_4.4"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
