extern krb5_error_code 
rd_and_store_for_creds(krb5_context, krb5_auth_context, krb5_data *, 
		       krb5_ticket *);

