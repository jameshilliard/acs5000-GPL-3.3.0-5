#ifndef K5CRYPTO_LIBINIT_H
#define K5CRYPTO_LIBINIT_H

int cryptoint_initialize_library (void);
void cryptoint_cleanup_library (void);

#endif /* K5CRYPTO_LIBINIT_H */
