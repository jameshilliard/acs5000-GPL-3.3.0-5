/* Encrypted password support */
#undef PAM_SMB_ENC_PASS

/* Has LOG_AUTHPRIV or LOG_AUTH */
#undef USE_LOGAUTH

/* Has LIBCRYPT */
#undef HAVE_LIBCRYPT
