#!/bin/bash

export LD_LIBRARY_PATH=../..
export PAMC_AGENT_PATH="../agents"

./test.libpamc
