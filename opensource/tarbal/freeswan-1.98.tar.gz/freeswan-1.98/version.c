/* silly pointless RCSID $Id: version.c,v 1.20 2001/10/24 02:22:18 henry Exp $ */
static const char freeswan_version[] = "1.92";
