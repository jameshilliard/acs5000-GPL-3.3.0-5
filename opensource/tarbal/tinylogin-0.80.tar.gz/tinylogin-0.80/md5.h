/* MD5.H - header file for MD5C.C */

char *md5_crypt(const char *pw);
