/*
 *  Module:  getifaddrs.c
 *
 *  Description: Get interface adddress (IPv4 and IPv6). Based on original
 *               getifaddrs(), but with IPv6 support.
 *
 *  Author:  Sergio Prado <sergio.prado@avocent.com>
 *
 *  Copyright:  (c) 2007 Avocent Corporation
 *
 *  Date:  October 4, 2007
 *
 *  Comments:
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <ifaddrs.h>
#include <string.h>
#include <net/if.h>

#define IPV6_ADDR_SCOPE_MASK    0x00f0U
#define IPV6_ADDR_LOOPBACK      0x0010U
#define IPV6_ADDR_LINKLOCAL     0x0020U
#define IPV6_ADDR_SITELOCAL     0x0040U
#define IPV6_ADDR_COMPATv4      0x0080U

#define DEBUG 0

static int convertScope(int scope) {
        switch (scope & IPV6_ADDR_SCOPE_MASK) {
        case 0:
                break;
        case IPV6_ADDR_LINKLOCAL:
                break;
        case IPV6_ADDR_SITELOCAL:
                break;
        case IPV6_ADDR_COMPATv4:
                break;
        case IPV6_ADDR_LOOPBACK:
                break;
        default:
		break;
        }
        return scope >> 4;
}

static void initNetmask(struct sockaddr_in6 *mask, int prefixLength) {

        memset(mask->sin6_addr.in6_u.u6_addr8,0,sizeof(mask->sin6_addr.in6_u.u6_addr8));

        unsigned char *bytes = mask->sin6_addr.in6_u.u6_addr8;

        int n = prefixLength / 8;

        int i;
        for (i=0; i < n; i++) {
            bytes[i] = 0xFF;
        }
        int pos = i;

        n = prefixLength % 8;

        for (i=0; i < n; i++) {
            bytes[pos] = bytes[pos] >> 1;
            bytes[pos] = bytes[pos] | 0x80;
        }
}

static int getPrefixLength(struct sockaddr_in6 *mask) {

        unsigned char *bytes = mask->sin6_addr.in6_u.u6_addr8;

        int n = 0;
        int i;
        for (i=15; i >=0 && bytes[i] == 0; i-- ) {
                n += 8;
        }

        int last = bytes[i];
        for (i=0; i<8 && ((last & 0x01) == 0); i++) {
                last = last >> 1;
                n ++;
        }

        return 128 - n;
}

static char *xinet_ntoa(struct sockaddr *server, char *buffer, int b_len) {
	
	struct sockaddr_storage addr;
	int addr_len = sizeof(addr);
	int n;

	if (server->sa_family == AF_INET) {
		addr_len = sizeof(struct sockaddr_in);
		memcpy(&addr,server,addr_len);
		server = (struct sockaddr *)&addr;
	} else if (server->sa_family == AF_INET6) {
		addr_len = sizeof(struct sockaddr_in6);
		memcpy(&addr,server,addr_len);
		server = (struct sockaddr *)&addr;
	}
	
	n = getnameinfo(server,addr_len,
			buffer,b_len,NULL,0,NI_NUMERICHOST);

#if DEBUG == 1
	if (n != 0) {
		fprintf(stderr, "error in getnameinfo - %d", n);
	}
#endif
	
	return buffer;
}


int getifaddrs6(struct ifaddrs **ifa) {
	
	char addr6[40], devname[20];
	struct sockaddr_in6 sap;
	int plen, scope, dad_status, if_idx;
	char addr6p[8][5];
	char str[INET6_ADDRSTRLEN];
	struct ifaddrs **ptr;

	*ifa = NULL;

	FILE *f = fopen("/proc/net/if_inet6", "r");

#if DEBUG == 1
	fprintf(stderr, "Starting getifaddrs6.\n");
#endif

	if (f != NULL) {
		while (fscanf
			   (f, "%4s%4s%4s%4s%4s%4s%4s%4s %08x %02x %02x %02x %20s\n",
				addr6p[0], addr6p[1], addr6p[2], addr6p[3], addr6p[4],
				addr6p[5], addr6p[6], addr6p[7], &if_idx, &plen, &scope,
				&dad_status, devname) != EOF
		) {
			sprintf(addr6, "%s:%s:%s:%s:%s:%s:%s:%s",
					addr6p[0], addr6p[1], addr6p[2], addr6p[3],
					addr6p[4], addr6p[5], addr6p[6], addr6p[7]);
			memset(&sap,0,sizeof(sap));
			inet_pton(AF_INET6, addr6, (struct in6_addr *) &sap.sin6_addr);
			sap.sin6_family = AF_INET6;        
			scope = convertScope(scope);
			sap.sin6_scope_id = scope;
			sap.sin6_port = 0;
			
			struct ifaddrs *naddr = (struct ifaddrs *)malloc(sizeof(struct ifaddrs));
                        memset(naddr,0,sizeof(*naddr));
			naddr->ifa_next = *ifa;
			*ifa = naddr;

			// address
			(*ifa)->ifa_addr = (struct sockaddr *)malloc(sizeof(sap));
			memcpy((*ifa)->ifa_addr,&sap,sizeof(sap));
                        
			memset(str,0,sizeof(str));
			xinet_ntoa((*ifa)->ifa_addr,str,sizeof(str));
			str[INET6_ADDRSTRLEN-1] = 0;

#if DEBUG == 1
			fprintf(stderr, "IPv6 %s %d - %s idx=%d scope=%d\n",
				str,plen,devname,if_idx,scope);
#endif

			// netmask
			(*ifa)->ifa_netmask = (struct sockaddr *)malloc(sizeof(sap));
			memset((*ifa)->ifa_netmask,0,sizeof(sap));
			(*ifa)->ifa_netmask->sa_family = AF_INET6;
			initNetmask((struct sockaddr_in6 *)(*ifa)->ifa_netmask,plen);

#if DEBUG == 1
			fprintf(stderr, "prefix: %d %d\n",
				getPrefixLength((struct sockaddr_in6 *)(*ifa)->ifa_netmask),plen);
#endif
				
			memset(str,0,sizeof(str));
			xinet_ntoa((*ifa)->ifa_netmask,str,sizeof(str));
			str[INET6_ADDRSTRLEN-1] = 0;

#if DEBUG == 1
			fprintf(stderr, "mask %s %d - %s idx=%d scope=%d\n",
				str,plen,devname,if_idx,scope);
#endif				

                        // name
                        (*ifa)->ifa_name = (char *)malloc(strlen(devname)+1);
                        strcpy((*ifa)->ifa_name,devname);

                        // flags
                        (*ifa)->ifa_flags = (*ifa)->ifa_flags | IFF_UP;
		}
		fclose(f);
	}

        //search the end of the list
        ptr = ifa;
        while (*ptr != NULL && (*ptr)->ifa_next != NULL) {
		ptr = (*ptr)->ifa_next;
	}
	
        // get ipv4 addresses
        getifaddrs(ptr);
	
#if DEBUG == 1
	fprintf(stderr, "Finishing getifaddrs6.\n");
#endif
	
	return(0);
}

void freeifaddrs6(struct ifaddrs *ifa) {
    
    struct ifaddrs *ptr = ifa;

    while (ptr != NULL) {

        if (ptr->ifa_addr->sa_family != AF_INET6) {

#if DEBUG == 1
	fprintf(stderr, "Releasing IPv4 addresses.\n");
#endif
		
		freeifaddrs(ptr);
		break;
        }

#if DEBUG == 1
	fprintf(stderr, "Releasing IPv6 addresses.\n");
#endif
	    
        free(ptr->ifa_addr);
        free(ptr->ifa_netmask);
        free(ptr->ifa_name);
        
        struct ifaddrs *tmp = ptr;
        ptr = ptr->ifa_next;
        free(tmp);        
    }
}

