/*==========================================================
 * Program : decode_pdu.h                  Project : smslink
 * Authors : Philippe Andersson.
 *           Fran�ois Baligant <francois@euronet.be>.
 * Date    : 12/01/02
 * Version : 0.01a
 * Notice  : (c) Les Ateliers du Heron, 1998 for Scitex Europe, S.A.
 * Comment : Header file for decode_pdu.c.
 *
 * Modification History :
 * - 0.01a (12/01/02) : Initial release.
 *========================================================*/

#ifndef _DECODE_PDU_H
#define _DECODE_PDU_H

#define DECODE_VERSION	"0.05b"
#define DECODE_DATE	"28/05/03"

/*==========================================================
 * Structure Declarations
 *========================================================*/

/*==========================================================
 * Function Declarations
 *========================================================*/

#endif                           /* #ifndef _DECODE_PDU_H */

/*==========================================================
 * EOF : decode_pdu.h
 *===================*/
