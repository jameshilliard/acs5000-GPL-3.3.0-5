/*
 * String to embed in binaries to identify package
 */

char pkg[]="$NetKit: netkit-ftp-0.17 $";
