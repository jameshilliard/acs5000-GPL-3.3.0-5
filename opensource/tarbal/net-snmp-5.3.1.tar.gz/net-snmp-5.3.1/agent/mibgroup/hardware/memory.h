config_require(hardware/memory/hw_mem)
config_arch_require(linux, hardware/memory/memory_linux)
