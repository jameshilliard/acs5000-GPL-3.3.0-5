/*	$NetBSD: rijndael.h,v 1.4 2006/09/09 16:22:36 manu Exp $	*/

/*	$KAME: rijndael.h,v 1.1.1.1 2001/08/08 09:56:27 sakane Exp $	*/

#include <crypto/rijndael/rijndael-api-fst.h>
