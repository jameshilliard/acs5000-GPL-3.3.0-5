int lib_server_dummy = 0;
