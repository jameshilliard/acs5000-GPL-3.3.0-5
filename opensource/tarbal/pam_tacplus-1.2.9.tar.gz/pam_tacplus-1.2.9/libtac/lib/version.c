/*
 * Copyright 1997-2000 by Pawel Krawczyk <kravietz@ceti.pl>
 *
 * See http://www.ceti.com.pl/~kravietz/progs/tacacs.html
 * for details.
 *
 * version.c  TACACS+ library version.
 */

int tac_ver_major = 1;
int tac_ver_minor = 6;
int tac_ver_patch = 5; /* patchlevel */
