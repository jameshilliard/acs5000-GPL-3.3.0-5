/* config.h.  Generated automatically by configure.  */
/* configure sets these don't change */

#define HAVE_LIBGDBM 1
/* #undef HAVE_LIBDBM */
/* #undef HAVE_LIBDB */

#define SIZEOF_CHAR 1
#define SIZEOF_SHORT 2
#define SIZEOF_INT 4
#define SIZEOF_LONG 4
