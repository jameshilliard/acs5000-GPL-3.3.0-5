config_require(hardware/cpu/cpu)
config_arch_require(linux, hardware/cpu/cpu_linux)
