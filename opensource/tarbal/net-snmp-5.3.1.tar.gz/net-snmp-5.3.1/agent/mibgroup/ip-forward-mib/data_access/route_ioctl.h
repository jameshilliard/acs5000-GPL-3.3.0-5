/*
 * internal header, not for distribution
 */

int _netsnmp_ioctl_route_set_v4(netsnmp_route_entry * entry);
int _netsnmp_ioctl_route_remove_v4(netsnmp_route_entry * entry);
int _netsnmp_ioctl_route_delete_v4(netsnmp_route_entry * entry);

