/*
 * Copyright (c) 1999, 2000, 2002 SuSE GmbH Nuernberg, Germany.
 * Author: Thorsten Kukuk <kukuk@suse.de>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, and the entire permission notice in its entirety,
 *    including the disclaimer of warranties.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior
 *    written permission.
 *
 * ALTERNATIVELY, this product may be distributed under the terms of
 * the GNU Public License, in which case the provisions of the GPL are
 * required INSTEAD OF the above restrictions.  (This clause is
 * necessary due to a potential bad interaction between the GPL and
 * the restrictions contained in a BSD-style copyright.)
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#define _GNU_SOURCE

#include <pwd.h>
#include <grp.h>
#include <time.h>
#include <errno.h>
#include <dlfcn.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <shadow.h>
#include <sys/types.h>

#define PAM_SM_ACCOUNT
#include <security/pam_modules.h>

#include "public.h"

#define SCALE (24L*3600L)

static int
hp_expire (pam_handle_t *pamh, int flags, const struct passwd *pw)
{
  long min, max;
  char *age;

  age = strchr (pw->pw_passwd, ',');
  if (age == NULL)
    return PAM_SUCCESS;
  ++age;

  max = c2n (age[0]);
  if (max < 0)
    {
    error_state:
      __pam_log (LOG_ERR, "Age field for %s is wrong", pw->pw_name);
      return PAM_ACCT_EXPIRED;
    }
  ++age;

  if (age == NULL)
    goto error_state;

  min = c2n (age[0]);
  if (min < 0)
    goto error_state;
  ++age;

  if ((max == 0 && min == 0) ||
      ((time(0)/(SCALE*7) > str2week (age) + max) && (max >= min)))
    {
      __write_message (pamh, flags, PAM_TEXT_INFO,
		       "Your password has expired. Choose a new password.");
      return PAM_NEW_AUTHTOK_REQD;
    }

  if (age == NULL)
    goto error_state;

  return PAM_SUCCESS;
}

static int
expire (pam_handle_t *pamh, int flags, const struct spwd *sp)
{
  long now;

  now = time (NULL) / SCALE;

  if (sp->sp_expire > 0 && now >= sp->sp_expire)
    {
      /* __write_message (pamh, flags,
	 "Your login has expired.  Contact the system administrator."); */
      return PAM_ACCT_EXPIRED;
    }

  if (sp->sp_lstchg == 0)
    {
      __write_message (pamh, flags, PAM_TEXT_INFO,
                       "Password changing requested. Choose a new password.");
      return PAM_NEW_AUTHTOK_REQD;
    }
  else if (sp->sp_lstchg > 0 && sp->sp_max >= 0 &&
	   (now > sp->sp_lstchg + sp->sp_max))
    {
      if (sp->sp_inact >= 0 &&
	  now >= sp->sp_lstchg + sp->sp_max + sp->sp_inact)
	{
	  /*__write_message (pamh, flags,
	    "Your password is inactive.  Contact the system administrator.");*/
	  return PAM_ACCT_EXPIRED;
	}
      if (sp->sp_max < sp->sp_min)
	{
	  /*__write_message (pamh, flags,
	    "Your password has expired.  Contact the system administrator.");*/
	  return PAM_ACCT_EXPIRED;
	}
      __write_message (pamh, flags, PAM_TEXT_INFO,
		       "Your password has expired. Choose a new password.");
      return PAM_NEW_AUTHTOK_REQD;
    }

  return PAM_SUCCESS;
}


int
pam_sm_acct_mgmt (pam_handle_t *pamh, int flags, int argc, const char **argv)
{
  int retval;
  int sp_buflen = 256;
  char *sp_buffer = alloca (sp_buflen);
  struct spwd sp_resultbuf;
  struct spwd *sp;
  int pw_buflen = 256;
  char *pw_buffer = alloca (pw_buflen);
  struct passwd pw_resultbuf;
  struct passwd *pw;
  const char *name;
  options_t *options;

  options = get_options ("account", argc, argv);
  if (options == NULL)
    {
      __pam_log (LOG_ERR, "cannot get options");
      return PAM_BUF_ERR;
    }

  if (options->debug)
    __pam_log (LOG_DEBUG, "pam_sm_acct_mgmt() called");

  /* If we use ldap, handle pam_ldap like "sufficient". If it returns
     success, we should also return success. Else ignore the call.  */
  if (options->use_ldap)
    {
      void *pam_ldap_handle;

      pam_ldap_handle = dlopen (PAMDIR"/pam_ldap.so", RTLD_NOW);
      if (pam_ldap_handle == NULL)
        {
          __pam_log (LOG_ERR, "dlopen(\""PAMDIR"/pam_ldap.so\") failed: %s",
                     dlerror ());
        }
      else
        {
          int (*pam_ldap_func) (pam_handle_t *, int, int, const char **);
          char *error;
          int retval = PAM_IGNORE;

          pam_ldap_func = dlsym (pam_ldap_handle, "pam_sm_acct_mgmt");
          if ((error = dlerror ()) != NULL)
            __pam_log (LOG_ERR, "dlsym failed: %s", error);
          else
            {
              retval = (*pam_ldap_func)(pamh, flags, 0, NULL);
              if (options->debug)
                __pam_log (LOG_DEBUG, "pam_ldap returned %d", retval);
            }

#if 0
          dlclose (pam_ldap_handle);
#endif

          if (retval == PAM_SUCCESS || retval == PAM_PERM_DENIED)
            return retval;
        }
    }

  /* get the user name */
  if ((retval = pam_get_user (pamh, &name, NULL)) != PAM_SUCCESS)
    return retval;

  while (getpwnam_r (name, &pw_resultbuf, pw_buffer, pw_buflen, &pw) != 0
         && errno == ERANGE)
    {
      errno = 0;
      pw_buflen += 256;
      pw_buffer = alloca (pw_buflen);
    }

  if (!pw)
    return PAM_USER_UNKNOWN;

  if (pw->pw_passwd == NULL || pw->pw_passwd[0] == '!')
    return PAM_PERM_DENIED;

  if (strchr (pw->pw_passwd, ',') != NULL)
    return hp_expire (pamh, flags, pw);

  while (getspnam_r (pw->pw_name, &sp_resultbuf, sp_buffer,
		     sp_buflen, &sp) != 0 && errno == ERANGE)
    {
      errno = 0;
      sp_buflen += 256;
      sp_buffer = alloca (sp_buflen);
    }

  if (sp == NULL) /* We have no shadow */
    return PAM_SUCCESS;

  if (sp->sp_pwdp && strcmp (sp->sp_pwdp, "*NP*") == 0)
    {
      uid_t save_uid = geteuid ();

      if (seteuid (pw->pw_uid) < 0)
        {
          __pam_log (LOG_ERR, "account: seteuid(%d) faild", pw->pw_uid);
          return PAM_PERM_DENIED;
        }

      while (getspnam_r (pw->pw_name, &sp_resultbuf, sp_buffer,
			 sp_buflen, &sp) != 0 && errno == ERANGE)
	{
	  errno = 0;
	  sp_buflen += 256;
	  sp_buffer = alloca (sp_buflen);
	}

      if (seteuid (save_uid) < 0)
        {
          __pam_log (LOG_ERR, "account: seteuid(%d) faild", save_uid);
          return PAM_PERM_DENIED;
        }
    }

  if (pw->pw_uid != 0)
    {
      retval = expire (pamh, flags, sp);
      if (retval != PAM_SUCCESS)
	return retval;
    }

  if (sp)
    {
      /* Print when the user has to change his password the next time ! */
      long now, remain;

      now = time (NULL) / SCALE;

      if (sp->sp_lstchg != -1 && sp->sp_max != -1 && sp->sp_warn != -1)
	{
	  if ((remain = (sp->sp_lstchg + sp->sp_max) - now) <= sp->sp_warn)
	    {
	      if (remain > 1)
		__write_message (pamh, flags, PAM_TEXT_INFO,
				 "Your password will expire in %ld days.",
				 remain);
	      else if (remain == 1)
		__write_message (pamh, flags, PAM_TEXT_INFO,
				 "Your password will expire tomorrow.");
	      else if (remain == 0)
		__write_message (pamh, flags, PAM_TEXT_INFO,
				 "Your password will expire within 24 hours.");
	    }
	}
    }
  return PAM_SUCCESS;
}
