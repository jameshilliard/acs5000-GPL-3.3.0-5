extern char *system_err_msg;
extern char *protocol_err_msg;
extern char *author_ok_msg;
extern char *author_fail_msg;
extern char *author_err_msg;
