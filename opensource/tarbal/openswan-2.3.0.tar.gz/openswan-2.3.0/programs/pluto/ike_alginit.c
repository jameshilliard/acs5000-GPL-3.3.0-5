extern int ike_alg_init(void);  int ike_alg_init(void) {
{ extern int ike_alg_aes_init (void); ike_alg_aes_init();}
return 0;}
