/* $OpenBSD: version.h,v 1.44 2005/03/16 21:17:39 markus Exp $ */

#define SSH_VERSION	"OpenSSH_4.1"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
