//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by C:\work\pismere\athena\auth\krb5\src\windows\identity\sample\templates\credprov\lang\en_us\langres.rc
//
#define IDD_PP_CRED                     106
#define IDD_PP_IDENT                    107
#define IDS_PLUGIN_DESC                 109
#define IDS_CT_SHORT_DESC               110
#define IDI_PLUGIN                      110
#define IDS_CT_LONG_DESC                111
#define IDD_NEW_CREDS                   112
#define IDS_NC_CT_TEMPLATE              112
#define IDS_NC_CT_TEMPLATE_NL           113
#define IDD_CONFIG                      113
#define IDS_GEN_NONE                    114
#define IDD_CONFIG_ID                   114
#define IDS_CFG_SHORT_DESC              115
#define IDD_CONFIG_IDS                  115
#define IDS_CFG_LONG_DESC               116
#define IDS_CFG_IDS_SHORT_DESC          117
#define IDS_CFG_IDS_LONG_DESC           118
#define IDS_CFG_ID_SHORT_DESC           119
#define IDS_CFG_ID_LONG_DESC            120

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
