/*==========================================================
 * Program : encode_pdu.h                  Project : smslink
 * Authors : Philippe Andersson.
 *           Fran�ois Baligant <francois@euronet.be>.
 * Date    : 13/01/02
 * Version : 0.01a
 * Notice  : (c) Les Ateliers du Heron, 1998 for Scitex Europe, S.A.
 * Comment : Header file for encode_pdu.c.
 *
 * Modification History :
 * - 0.01a (13/01/02) : Initial release.
 *========================================================*/

#ifndef _ENCODE_PDU_H
#define _ENCODE_PDU_H

#define ENCODE_VERSION	"O.O3b"
#define ENCODE_DATE	"29/01/02"

/*==========================================================
 * Structure Declarations
 *========================================================*/

/*==========================================================
 * Function Declarations
 *========================================================*/

#endif                           /* #ifndef _ENCODE_PDU_H */

/*==========================================================
 * EOF : encode_pdu.h
 *===================*/
