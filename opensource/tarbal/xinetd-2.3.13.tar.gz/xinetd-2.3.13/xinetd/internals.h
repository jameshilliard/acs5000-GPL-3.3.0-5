#ifndef INTERNALS_H
#define INTERNALS_H

#include "config.h"
#include "defs.h"

void dump_internal_state(void);
void user_requested_check(void);
void enable_periodic_check( unsigned );
#endif
