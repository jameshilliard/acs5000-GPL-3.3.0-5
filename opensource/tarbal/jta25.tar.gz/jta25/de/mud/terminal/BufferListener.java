package de.mud.terminal;

public interface BufferListener {
    public void handleBufferEvent(BufferEvent e);
}


