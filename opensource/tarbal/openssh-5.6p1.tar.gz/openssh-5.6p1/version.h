/* $OpenBSD: version.h,v 1.59 2010/08/08 16:26:42 djm Exp $ */

#define SSH_VERSION	"OpenSSH_5.6"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
