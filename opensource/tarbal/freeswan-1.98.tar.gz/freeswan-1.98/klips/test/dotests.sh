#!/bin/sh

. ../../umlsetup.sh

. setup.sh

. functions.sh

source TESTLIST


