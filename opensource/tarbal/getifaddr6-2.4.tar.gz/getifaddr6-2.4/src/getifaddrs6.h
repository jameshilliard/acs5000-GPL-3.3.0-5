/*
 *  Module:  getifaddrs.h
 *
 *  Description: Get interface adddress (IPv4 and IPv6). Based on original
 *               getifaddrs(), but with IPv6 support.
 *
 *  Author:  Sergio Prado <sergio.prado@avocent.com>
 *
 *  Copyright:  (c) 2007 Avocent Corporation
 *
 *  Date:  October 4, 2007
 *
 *  Comments:
 *
 */

int getifaddrs6(struct ifaddrs **ifa);
void freeifaddrs6(struct ifaddrs *ifa);
