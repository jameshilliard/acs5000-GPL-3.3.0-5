char * mgetty_version = "interim release 1.1.33-Apr10";
